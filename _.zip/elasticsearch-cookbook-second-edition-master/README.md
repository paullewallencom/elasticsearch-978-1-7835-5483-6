elasticsearch-cookbook
======================

PacktPub ElasticSearch CookBook code repository


The code on MacOSX, Linux, FreeBSD and other Unix based systems everything should be installed in a default installation.

For windows users
-----------------

I suggest to install a "Sane shell environment on Windows". Instructions are available on:
http://blog.ruilopes.com/post/2143557964/sane-shell-environment-on-windows

For downloading curl for Windows:
http://www.confusedbycode.com/curl/#downloads

Generally a bash shell and curl must be installed.

These are very common tools in ElasticSearch community.

